# Crypto-News-Offers
Android app  for fetching latest, popular and trending news about popular cyptocurrency on the web
![download (2)](https://user-images.githubusercontent.com/32623706/58623102-18567c00-82c5-11e9-9bab-cfe7b0fc2121.png)
![download (1)](https://user-images.githubusercontent.com/32623706/58623117-273d2e80-82c5-11e9-9c34-8cec4e9f4fe5.png)
![download (3)](https://user-images.githubusercontent.com/32623706/58623168-45a32a00-82c5-11e9-893e-7474374519a1.png)
![download](https://user-images.githubusercontent.com/32623706/58623252-7aaf7c80-82c5-11e9-900c-1d1d0d78b8bf.png)
